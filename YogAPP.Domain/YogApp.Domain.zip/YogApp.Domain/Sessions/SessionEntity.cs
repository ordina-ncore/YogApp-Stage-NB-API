﻿using YogApp.Domain.Shared;

namespace YogApp.Domain.Sessions;

public class SessionEntity : EntityBase
{
}
