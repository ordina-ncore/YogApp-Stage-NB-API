﻿namespace YogApp.Domain.Sessions;

public class SessionDomain
{
}
