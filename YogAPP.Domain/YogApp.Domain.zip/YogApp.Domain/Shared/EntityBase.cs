﻿namespace YogApp.Domain.Shared;

public abstract class EntityBase
{
    public Guid Id { get; init; }
}
